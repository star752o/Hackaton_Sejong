package ssaemo;

import java.sql.*;
import jp.*;

public class NoteTBController extends TableController
{
	private String TABLE_NAME = "note_table";
	
	private static NoteTBController singletonInstance;
	
	private NoteTBController() {}
	
	public static NoteTBController getInstance()
	{
		if(singletonInstance == null) singletonInstance = new NoteTBController();
		
		return singletonInstance;
	}
	
	public ResultSet getNotes(Connection conn)
	{
		String query = "SELECT * FROM " + TABLE_NAME;
		
		ResultSet rs = execQuery(conn, query);
		
		return rs;
	}
	
	public void insertNote(Connection conn, Notes note)
	{
		String query = "INSERT INTO " + TABLE_NAME + " VALUES (" + 
						note.xpos + ", " + note.ypos + ", '" + note.text.getText() + "')";
		System.out.println("query: " + query);
		
		execUpdate(conn, query);
	}
	
	public void updateNote(Connection conn, Notes note)
	{
		String query = "UPDATE " + TABLE_NAME + " SET contents='" + note.text.getText() + "' " + 
						"WHERE xpos=" + note.xpos + " and ypos=" + note.ypos;
		System.out.println("query: " + query);

		execUpdate(conn, query);
	}
}
