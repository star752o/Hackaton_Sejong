package ssaemo;

import java.sql.*;


public class FileController extends TableController
{
	private String TABLE_NAME = "file_table";
	
	private static FileController singletonInstance;
	
	private FileController() {}
	
	public static FileController getInstance()
	{
		if(singletonInstance == null) singletonInstance = new FileController();
		
		return singletonInstance;
	}
	
	public ResultSet getFileList(Connection conn)
	{
		String query = "SELECT file_name FROM " + TABLE_NAME;
		
		ResultSet rs = execQuery(conn, query);
		
		return rs;
	}
	
	public void uploadFile(Connection conn, String file_name, byte[] file_binary)
	{
		String query = "INSERT INTO " + TABLE_NAME + " VALUES(" + file_name + ", " + file_binary + ")";
		
		execUpdate(conn, query);
	}
}
