package ssaemo;

import java.sql.*;

public class TitleTBController extends TableController
{
	private String TABLE_NAME = "title_table";

	
	private static TitleTBController singletonInstance;
	
	private TitleTBController() {}
	
	public static TitleTBController getInstance()
	{
		if(singletonInstance == null) singletonInstance = new TitleTBController();
		
		return singletonInstance;
	}
	
	public ResultSet getProjectInfo(Connection conn, String project_name)
	{
		String query = "SELECT * FROM " + TABLE_NAME + 
						" WHERE project_name = '" + project_name + "'";
		System.out.println("query: " + query);
		
		ResultSet rs = execQuery(conn, query);
		
		return rs;
	}
}
