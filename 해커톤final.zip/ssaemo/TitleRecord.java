package ssaemo;

public class TitleRecord 
{
	
}
