package ssaemo;

import java.sql.*;

public class LectureRoomTBController extends TableController
{
	private String TABLE_NAME = "lecture_room_table";
	
	private static LectureRoomTBController singletonInstance;
	
	private LectureRoomTBController() {}
	
	public static LectureRoomTBController getInstance()
	{
		if(singletonInstance == null) singletonInstance = new LectureRoomTBController();
		
		return singletonInstance;
	}

	public ResultSet getEmptyLectureRoomList(Connection conn, String day, String time)
	{
		String timeFormat = "TIME_FORMAT('" + time + ":00', '%h:%i:%s')";
		String query = "SELECT * FROM " + TABLE_NAME + 
						" where day LIKE '%" + day + "%'" + 
						" and (" + timeFormat + " < start_time OR " + 
						"end_time <= " + timeFormat + ")";
		
		System.out.println("query: " + query);
		
		ResultSet rs = execQuery(conn, query);
		
		return rs;
	}
}