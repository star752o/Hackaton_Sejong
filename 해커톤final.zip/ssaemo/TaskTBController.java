package ssaemo;

import java.sql.*;

// DB���� record�� insert, select�ϴ� Ŭ����
public class TaskTBController extends TableController
{
	private String TABLE_NAME = "task_table";
	
	private static TaskTBController singletonInstance;
	
	private TaskTBController() {}
	
	public static TaskTBController getInstance()
	{
		if(singletonInstance == null) singletonInstance = new TaskTBController();
		
		return singletonInstance;
	}
	
	// TaskList�� ResultSet Ÿ������ ��ȯ�ϴ� �޼ҵ�
	public ResultSet getTaskList(Connection conn, int user_index)
	{
		String query = "SELECT * FROM " + TABLE_NAME + 
						" where user_index = " + user_index;
		
		ResultSet rs = execQuery(conn, query);
		
		return rs;
	}
	
	// Task�� DB�� �����ϴ� �޼ҵ�
	public void insertTask(Connection conn, TaskRecord task)
	{
		String query = "INSERT INTO " + TABLE_NAME + " VALUES (" + 
						task.getInsertValues() + ")";
		System.out.println("query: " + query);

		execUpdate(conn, query);
	}
	
	public void updateTask(Connection conn, TaskRecord task, String setQuery)
	{
		String query = "UPDATE " + TABLE_NAME + 
						" SET " + setQuery + 
						" WHERE " + task.getWhereCondition();
		System.out.println("query: " + query);
		
		execUpdate(conn, query);
	}
}
