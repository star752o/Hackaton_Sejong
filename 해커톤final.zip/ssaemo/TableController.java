package ssaemo;

import java.sql.*;

public class TableController 
{
	protected ResultSet execQuery(Connection conn, String query)
	{
		ResultSet rs = null;
		
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
		}
		catch(SQLException e) { e.printStackTrace(); }
		
		return rs;
	}
	protected void execUpdate(Connection conn, String query)
	{
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.executeUpdate();
		}
		catch(SQLException e) { e.printStackTrace(); }
	}
}
