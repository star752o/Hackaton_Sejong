package ssaemo;

import java.sql.*;

public class ExcelParser 
{
	public void sendToDB()
	{
		final String DB_NAME = "HackatonDB";
		final String TABLE_NAME = "task_table";
		final String URL = "jdbc:mysql://52.79.84.13:3306/"+DB_NAME;
		final String DB_ID = "Hackaton";
		final String DB_PW = "sejong";
		
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
				
			connection = DriverManager.getConnection(URL, DB_ID, DB_PW);
			String query = "SELECT * FROM " + TABLE_NAME;
			pstmt = connection.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next())
			{
				System.out.format("%s", rs.getString("ID"));
			}
		}
		catch(ClassNotFoundException e) { System.out.println("ClassNotFound: "+e); }
		catch(SQLException e) { System.out.println("SQL: "+e); }
	}
	
	public static void main(String[] argv)
	{
		ExcelParser p = new ExcelParser();
		p.sendToDB();
	}
}
