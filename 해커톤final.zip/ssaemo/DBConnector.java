package ssaemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector 
{
	private static final String DB_NAME = "HackatonDB";
	private static final String URL = "jdbc:mysql://52.79.84.13:3306/"+DB_NAME;
	private static final String DB_ID = "Hackaton";
	private static final String DB_PW = "sejong";

	private static DBConnector singletonInstance; 
	
	private DBConnector() 
	{
		try
		{
			// JDBC ����̹� �ε�
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(ClassNotFoundException e) 
		{ 
			System.out.println("ClassNotFound: " + e); 
		}
	}
	
	public static DBConnector getInstance()
	{
		if (singletonInstance == null) 
			singletonInstance = new DBConnector();
		
		return singletonInstance;
	}
	
	// JDBC Ŀ�ؼ��� ��ȯ�ϴ� �޼ҵ� 
	public Connection getConnection()
	{
		Connection conn = null;
		
		try
		{
			conn = DriverManager.getConnection(URL, DB_ID, DB_PW);
		}
		catch(SQLException e) { System.out.println(e); }
		
		return conn;
	}

}
