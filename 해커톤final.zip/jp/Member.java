package jp;

import java.awt.event.*;
import javax.swing.*;

import ssaemo.*;

import java.sql.*;

public class Member extends JPanel {
	public int user_index;
	public String start_date;
	public String end_date;
	public String user_name;
	public String contents;
	public int complete;

	public JTextPane textPane;
	private JCheckBox checkBox;

	private int compGap = 10;
	
	// add task
	public Member(int xpos, int ypos, int boxW, int boxH, int user_index, String user_name)
	{
		this.user_index = user_index;
		this.start_date = null;
		this.end_date = null;
		this.user_name = user_name;
		this.contents = null;
		this.complete = 0;
		
		init(xpos, ypos, boxW, boxH);
	}
	
	public Member(ResultSet rs)
	{
		try
		{
			user_index = rs.getInt("user_index");
			start_date = rs.getString("start_date");
			end_date = rs.getString("end_date");
			user_name = rs.getString("user_name");
			contents = rs.getString("contents");
			complete = rs.getInt("complete");
		}
		catch(SQLException e) { e.printStackTrace(); }
	}
	
	// DB�� task
	public Member(int xpos, int ypos, int boxW, int boxH, ResultSet rs)
	{
		try
		{
			user_index = rs.getInt("user_index");
			start_date = rs.getString("start_date");
			end_date = rs.getString("end_date");
			user_name = rs.getString("user_name");
			contents = rs.getString("contents");
			complete = rs.getInt("complete");
		}
		catch(SQLException e) { e.printStackTrace(); }
		
		init(xpos, ypos, boxW, boxH);
	}
	
	public void init(int xpos, int ypos, int boxW, int boxH)
	{
		setBounds(xpos, ypos, boxW + compGap + 21, 40);
		setLayout(null);
		
		textPane = new JTextPane();
		textPane.setText(contents);
		textPane.setBounds(0, 0, boxW, boxH);
		add(textPane);
		checkBox = new JCheckBox();
		if(complete == 1)
			checkBox.setSelected(true);
		else
			checkBox.setSelected(false);
		checkBox.setBounds(boxW + compGap, compGap, 21, 23);
		checkBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Connection conn = DBConnector.getInstance().getConnection();
				TaskTBController.getInstance().updateTask(	conn, 
															new TaskRecord(start_date,
																			end_date,
																			user_index,
																			user_name,
																			contents,
																			complete), 
															"complete=1");
				
				System.out.println("INDEX" + 
									user_index +
									" " +
									user_name +
									" " +
									contents +
									" Button Pressed.");
			}});
		add(checkBox);
	}
	
	public void removeSelf()
	{
		removeAll();
	}
}
