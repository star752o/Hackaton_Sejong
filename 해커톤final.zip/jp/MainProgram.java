package jp;

public class MainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame frame = new MyFrame();
		frame.setSize(1024,768);
		frame.setVisible(true);
	}

}
