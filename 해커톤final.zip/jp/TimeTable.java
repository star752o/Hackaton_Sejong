package jp;

import javax.swing.JTextArea;

public class TimeTable {
	public String building;
	public String room_no;
	public String building_room_no;
	
	public JTextArea class_no;
	//public 
}
