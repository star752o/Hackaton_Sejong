package jp;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

import ssaemo.*;

public class MemberWorks extends JPanel {
	private JScrollPane scrollPane;
	private JPanel newUser;
	
	private int user_index;
	private String user_name;
	private JLabel lblUserName;
	private Member lastMember;
	private JButton btnAddCommit;
	private JButton btnAddCancel;
	private JButton btnAdd;
	
	private int xpos = 10;
	private int ypos = 10 + 30;
	private int lineGap = 15;
	private int boxW = 280;
	private int boxH = 40;
	
	public MemberWorks(int user_index) {
		setSize(334,650);
		setLayout(null);

		Connection conn = DBConnector.getInstance().getConnection();
		ResultSet rs = TaskTBController.getInstance().getTaskList(conn, user_index);
		
		//Send Quary with id
		//Get Quary to ResultSet

		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 334, 650);
		add(scrollPane);
		
		newUser = new JPanel();
		newUser.setLayout(null);
		scrollPane.setViewportView(newUser);
		
		/* init instance variables */
		this.user_index = user_index;
		user_name = null;
		
		lblUserName = new JLabel();
		lblUserName.setBounds(12, 10, 200, 15);
		
		btnAddCommit = new JButton("Commit");
		btnAddCommit.setVisible(false);
		btnAddCommit.addActionListener(new AddButtonListener());
		newUser.add(btnAddCommit);
		
		btnAddCancel = new JButton("Cancel");
		btnAddCancel.setVisible(false);
		btnAddCancel.addActionListener(new AddButtonListener());
		newUser.add(btnAddCancel);

		// add button
		btnAdd = new JButton("Add Task");
		btnAdd.addActionListener(new AddButtonListener());
		newUser.add(btnAdd);
		
		// DB�κ��� �޾ƿ� TaskList ��ġ
		try
		{
			while(rs.next())
			{
				addTask(rs);
			}
		}
		catch(Exception e){}
		
		// btnAdd �� �Ʒ��� ��ġ
		btnAdd.setBounds(xpos, ypos, boxW, boxH);
	}
	
	private void addTask(ResultSet rs)
	{
		
		if(user_name == null)
		{
			try
			{
				user_name = rs.getString("user_name");
			}
			catch(SQLException e) { e.printStackTrace(); }
			lblUserName.setText(user_name);
		}
		
		// add task
		if (rs == null)
			lastMember = new Member(xpos, ypos, boxW, boxH, user_index, user_name);
		// DB�� task
		else // rs != null
			lastMember = new Member(xpos, ypos, boxW, boxH, rs);
		newUser.add(lastMember);
		
		incYPos();

		btnAdd.setBounds(xpos, ypos, boxW, boxH);

		repaint();
	}
	
	private void incYPos()
	{
		ypos = ypos + (boxH + lineGap);
	}
	private void decYPos()
	{
		ypos = ypos - (boxH + lineGap); 
	}
	
	private class AddButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) 
		{
			Object obj = e.getSource();
			if(obj == btnAdd)
			{
				addTask(null);

				btnAdd.setBounds(xpos, ypos, boxW, boxH);
				btnAdd.setVisible(false);
				
				int half = boxW/2;
				
				btnAddCommit.setBounds(xpos, 		ypos, half, 40);
				btnAddCommit.setVisible(true);
				btnAddCancel.setBounds(xpos + half, ypos, half, 40);
				btnAddCancel.setVisible(true);
			}
			else if (obj == btnAddCommit)
			{
				System.out.println("Commit");
				
				btnAddCommit.setVisible(false);
				btnAddCancel.setVisible(false);
				
				btnAdd.setVisible(true);
				
				// db�� update
				lastMember.contents = lastMember.textPane.getText();
				Connection conn = DBConnector.getInstance().getConnection();
				TaskRecord task = new TaskRecord(lastMember);
				TaskTBController.getInstance().insertTask(conn, task);
			}
			else if (obj == btnAddCancel)
			{
				System.out.println("Cancel");
				
				btnAddCommit.setVisible(false);
				btnAddCancel.setVisible(false);
				
				btnAdd.setVisible(true);
				
				lastMember.removeSelf();
				newUser.remove(lastMember);
				newUser.repaint();
				
				decYPos();
				
				btnAdd.setBounds(xpos, ypos, boxW, boxH);
			}
		}
	}
}
