package jp;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Announcements extends JPanel {
	public Announcements(){
		this.setSize(1008, 50);
		this.setLayout(null);
		
		JLabel title1 = new JLabel("Project Name : ");
		JLabel title2 = new JLabel("Fianl Due : ");
		title1.setBounds(5, 5, 100, 20);
		title2.setBounds(5, 25, 100, 20);
		this.add(title1);
		this.add(title2);
		
		//GET INFO from DB
		JLabel proj_name = new JLabel("SAMPLE: NEW PROJ 1.");
		JLabel final_due = new JLabel("SAMPLE: TODAY 2010-00-00");
		proj_name.setBounds(100, 5, 1008-100, 20);
		final_due.setBounds(100, 25, 1008-100, 20);
		this.add(proj_name);
		this.add(final_due);
	}
}
