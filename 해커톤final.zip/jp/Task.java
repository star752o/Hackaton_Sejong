package jp;

import java.text.*;
import java.util.*;

// task_table�� record(=line)�� ������ ��ü (insert �� �� ���)
public class Task
{
	// Java�� Date Ÿ���� MySQL�� DATETIME Ÿ������ formatting���ֱ� ���� ��ü
	static SimpleDateFormat sdf;
	
	private Date start_date;
	private Date end_date;
	private int user_index;
	private String user_name;
	private String contents;
	private int complete;
	
	public Task(String start_date,
				String end_date,
				int user_index,
				String user_name,
				String contents,
				int complete)
	{
		if(Task.sdf == null) sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		try
		{
			this.start_date = sdf.parse(start_date);
			this.end_date 	= sdf.parse(end_date);
			this.user_index = user_index;
			this.user_name 	= user_name;
			this.contents 	= contents;
			this.complete 	= complete;
		}
		catch(ParseException e) { System.out.println(e); }
	}
	
	
	//public String 	getStartDateStr() 	{ return sdf.format(start_date); }
	//public String 	getEndDateStr() 	{ return sdf.format(end_date); }
	//public int 		getUserIndex() 		{ return user_index; }
	//public String 	getUserName() 		{ return user_name; }
	//public String 	getContents()		{ return contents; }	
	//public int 		getComplete() 		{ return complete; }
	
	public String 	getInsertValues()
	{
		return sdf.format(start_date) + 
				sdf.format(end_date) + 
				user_index + 
				user_name + 
				contents + 
				complete;
	}
	public String	getWhereCondition()
	{
		return "start_date = " + sdf.format(start_date) + 
				"and end_date = " + sdf.format(end_date) + 
				"and user_index = " + user_index + 
				"and user_name = " + user_name + 
				"and contents = " + contents + 
				"and complete = " + complete;
	}
}
