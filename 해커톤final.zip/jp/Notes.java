package jp;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Notes extends JPanel{
	private static final int NONE = -1;
	
	public JButton btnCommit;
	
	public JTextArea text;
	public JPanel delete;
	public int xpos;
	public int ypos;
	
	public Notes()
	{
		this(NONE, NONE, "", 200, 150);
	}
	
	public Notes(int xpos, int ypos, String str, int width, int height){
		this.setLayout(null);
		this.setSize(width, height);
		
		btnCommit = new JButton("*");
		btnCommit.setBounds(150, 95, 45, 30);
		add(btnCommit);
		
		//this.setBackground(Color.GRAY);
		text = new JTextArea("New Note.");
		text.setBounds(3, 3, 200-6, 130);
		this.add(text);
		
		delete = new JPanel();
		delete.setSize(200-6, 10);
		delete.setBackground(Color.RED);
		delete.setBounds(3, 137, 200-6, 10);
		this.add(delete);

		this.xpos = xpos;
		this.ypos = ypos;
		text.setText(str);
		
		if(xpos != NONE && ypos != NONE)
			setBounds(xpos, ypos, width, height);
	}
}
