package jp;

import java.sql.*;
import java.util.Date;
import java.text.SimpleDateFormat;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Scheduling extends JPanel {
	
	int posX = 10, posY = 10;
	long projbegin, diff, duration, startday, day, ratio;
	int N = 2; /*ONLY TEST PURPOSE*/
	long blkW = 100;
	long blkH = 40;
	long gap = 5;
	
	public Scheduling(){
		this.setLayout(null);
		this.setSize(1003*4, 650);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 45, 1003, 605);
		add(scrollPane);
		
		JPanel diagramPnl = new JPanel();
		scrollPane.setViewportView(diagramPnl);
		
		JButton btnLoadData = new JButton("Load Data");
		btnLoadData.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				diagramPnl.removeAll();
				//GET from DB about begin
				ResultSet rs = null;
				Member memBegin = new Member(rs);
				
				//GET from DB about End
				rs = null;
				Member memEnd = new Member(rs);
				
				//GET from DB about N
				rs = null;
				try {
					N = rs.getInt("user_cnt");
				} 
				catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				//Find diff of begin and end date
				SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
				try{
					Date beginDate = fm.parse(memBegin.start_date);
					projbegin = beginDate.getTime()/(24*60*60*1000);
					Date endDate = fm.parse(memEnd.end_date);
					diff = endDate.getTime() - beginDate.getTime();
					duration = diff / (24 * 60 * 60 * 1000);
				}
				catch(Exception err){};
				
				//Resize if duration is way over preserved size
				if(duration >= 1003*4/100){
					ratio = (1003*4/100) / (duration);
					blkW *= ratio;
					blkH *= ratio;
					gap *= ratio;
				}
				
				//GET from DB about each data
				ResultSet rs2 = null;				
				try {
					while(rs2.next()){
						Member mem2 = new Member(rs);
						//Find diff of sigle task
						try{
							Date beginDate = fm.parse(mem2.start_date);
							Date endDate = fm.parse(mem2.end_date);
							diff = endDate.getTime() - beginDate.getTime();
							startday = beginDate.getTime() / (24*60*60*1000);
							day = diff / (24 * 60 * 60 * 1000);
							
							String str = mem2.user_name + ": " + mem2.contents + "\n" + mem2.start_date + "\n" + mem2.end_date;
							
							JPanel assignPnl2 = new JPanel();
							//assignPnl2.setBac
							JPanel assignPnl = new JPanel();
							//assignPnl.setBorder();
							JTextArea assignment = new JTextArea(str);
							assignPnl.add(assignment);
							assignPnl.setBounds((int)(posX + (startday-projbegin)*blkW), (int)(posY + (gap+blkH)*(mem2.user_index)), (int)(day*blkW), (int)(blkH));
							diagramPnl.add(assignPnl);
						}
						catch(Exception err){};
					}
				} 
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnLoadData.setBounds(12, 10, 97, 23);
		add(btnLoadData);
		
	}
}
