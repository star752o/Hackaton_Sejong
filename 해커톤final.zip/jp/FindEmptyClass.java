package jp;

import javax.swing.JPanel;
import java.sql.*;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import ssaemo.DBConnector;
import ssaemo.LectureRoomTBController;
import javax.swing.JScrollBar;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

public class FindEmptyClass extends JPanel {
	public FindEmptyClass() {
		this.setLayout(null);
		this.setSize(1003, 650);
		
		JPanel imgPnl = new JPanel();
		imgPnl.setBounds(0, 0, 1003, 378);
		add(imgPnl);
		imgPnl.setLayout(null);
		
		JPanel optionPnl = new JPanel();
		optionPnl.setBackground(Color.WHITE);
		optionPnl.setBounds(0, 376, 1003, 51);
		add(optionPnl);
		optionPnl.setLayout(null);
		
		JLabel lblSelectDay = new JLabel("Select Day");
		lblSelectDay.setBounds(42, 17, 74, 15);
		optionPnl.add(lblSelectDay);
		
		JLabel lblSelectTime = new JLabel("Select Time");
		lblSelectTime.setBounds(471, 17, 74, 15);
		optionPnl.add(lblSelectTime);
		
		JComboBox comboBoxDay = new JComboBox();
		comboBoxDay.setBounds(137, 14, 254, 21);
		optionPnl.add(comboBoxDay);
		comboBoxDay.addItem("��");
		comboBoxDay.addItem("ȭ");
		comboBoxDay.addItem("��");
		comboBoxDay.addItem("��");
		comboBoxDay.addItem("��");
				
		JComboBox comboBoxTime = new JComboBox();
		comboBoxTime.setBounds(572, 14, 268, 21);
		optionPnl.add(comboBoxTime);
		comboBoxTime.addItem("09:00");
		comboBoxTime.addItem("09:30");
		comboBoxTime.addItem("10:00");
		comboBoxTime.addItem("10:30");
		comboBoxTime.addItem("11:00");
		comboBoxTime.addItem("11:30");
		comboBoxTime.addItem("12:00");
		comboBoxTime.addItem("12:30");
		comboBoxTime.addItem("13:00");
		comboBoxTime.addItem("13:30");
		comboBoxTime.addItem("14:00");
		comboBoxTime.addItem("14:30");
		comboBoxTime.addItem("15:00");
		comboBoxTime.addItem("15:30");
		comboBoxTime.addItem("16:00");
		comboBoxTime.addItem("16:30");
		comboBoxTime.addItem("17:00");
		comboBoxTime.addItem("17:30");
		comboBoxTime.addItem("18:00");

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 425, 1003, 225);
		add(scrollPane);
		
		JPanel resultPnl = new JPanel();
		resultPnl.setSize(1003, 225*3);
		scrollPane.add(resultPnl);
		scrollPane.setViewportView(resultPnl);
		resultPnl.setLayout(new GridLayout(1, 0, 0, 0));
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//GET info
				String strDay = comboBoxDay.getSelectedItem().toString();
				String strTime = comboBoxTime.getSelectedItem().toString();
				Connection conn = DBConnector.getInstance().getConnection();
				
				//Send to DB
				
				//Get info from DB
				ResultSet rs = LectureRoomTBController.getInstance().getEmptyLectureRoomList(conn, strDay, strTime);
				
				int posX = 10;
				int posY = 10;
				int boxW = 1003-40;
				int boxH = 25;
				int gap = 5;
				resultPnl.removeAll();
				try{
					while(rs.next()){
						TimeTable tbl = new TimeTable();
						//tbl.building = rs.getString("building");
						//tbl.room_no = rs.getString("room_no");
						tbl.building_room_no = rs.getString("location");
						
						System.out.println(tbl.building_room_no);
						tbl.class_no = new JTextArea(tbl.building_room_no);
						tbl.class_no.setBounds(posX, posY, boxW, boxH);
						resultPnl.add(tbl.class_no);
						repaint();
						posY = posY + boxH + gap;
					}
				}
				catch(Exception err){ err.printStackTrace(); };
			}
		});
		btnSearch.setBounds(866, 13, 97, 23);
		optionPnl.add(btnSearch);
	}
}
