package jp;

import java.sql.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import ssaemo.*;

public class MyFrame extends JFrame {
	/*Announcement Panel*/
	JPanel AnnouncementPanel;
	
	/*Main Panel*/
	JPanel MainPanel, subPnl;
	JScrollPane scrollPane;
	
	/*IDEA BOARD PANEL*/
	JPanel IdeaBoardPanel, IdeaNotes;
	
	/*FIND EMPTY CLASS PANEL*/
	JPanel FindEmptyClassPanel;
	
	/*FIND FILE SHARING PANEL*/
	JPanel FileSharingPanel;
	
	/*SCHEDULE PANEL*/
	JPanel SchedulePanel;
	
	public MyFrame() {
		this.setSize(1024, 768);
		getContentPane().setLayout(null);
		
		/*ANNOUNCEMENT PANEL*/
		AnnouncementPanel = new Announcements();
		AnnouncementPanel.setBounds(0, 0, 1008, 50);
		FlowLayout flowLayout = (FlowLayout) AnnouncementPanel.getLayout();
		AnnouncementPanel.setBackground(Color.YELLOW);
		getContentPane().add(AnnouncementPanel);
		
		/*MAIN PANEL*/
		JTabbedPane TapContainter = new JTabbedPane(JTabbedPane.TOP);
		TapContainter.setBounds(0, 50, 1008, 679);
		getContentPane().add(TapContainter);
		
		MainPanel = new JPanel();
		TapContainter.addTab("Main", null, MainPanel, null);
		MainPanel.setLayout(null);
		refreshMemberWorks();		
		
		/*IDEA BOARD PANEL*/
		IdeaBoardPanel = new JPanel();
		TapContainter.addTab("Idea Board", null, IdeaBoardPanel, null);
		IdeaBoardPanel.setLayout(null);
		refreshIdeaNotes();

		/*FIND EMPTY CLASS PANEL*/
		FindEmptyClassPanel = new FindEmptyClass();
		TapContainter.addTab("Find Empty Class", null, FindEmptyClassPanel, null);
		FindEmptyClassPanel.setLayout(null);
		
		/*FILE SHARING*/
		FileSharingPanel = new FileTransfering();
		TapContainter.addTab("File Sharing", null, FileSharingPanel, null);
		FileSharingPanel.setLayout(null);
		
		/*SCHEDULE*/
		SchedulePanel = new Scheduling();
		TapContainter.addTab("Schedule", null, SchedulePanel, null);
		SchedulePanel.setLayout(null);
		
		
	}//public MyFrame
	
	public void refreshMemberWorks(){		
		scrollPane = new JScrollPane();
		subPnl = new JPanel();
		subPnl.setBounds(0, 0, 1003, 650 * 4);
		subPnl.setLayout(null);
		scrollPane.setBounds(0, 0, 1003, 650);
		scrollPane.setViewportView(subPnl);
		MainPanel.add(scrollPane);
		
		int N = 0;
		int xpos = 0;
		int ypos = 0;
		int xwidth = 334;
		int yheight = 650;
		
		try{
			for(int i=0; i<2; i++){
				//CREATE MemberWorks class
			
				/*//��ġ�� �����ϸ鼭 ���������� ��� Ŭ���� ���� �� ����
				if(rs != null)
					System.out.println("We got data!");
				else
					System.out.println("No data");
				*///
				
				MemberWorks member = new MemberWorks(i);
				member.setBounds(xpos, ypos, xwidth, yheight);
				subPnl.add(member);
				
				xpos += xwidth;
				if(xpos >= xwidth * 3){
					xpos = 0;
					ypos += yheight;
				}
			}
		}
		catch(Exception e){}
	}//refreshMemberWorks
	
	public void refreshIdeaNotes(){
		IdeaNotes = new IdeaNotes();
		IdeaBoardPanel.add(IdeaNotes);
	}//refreshIdeaNotes
}
