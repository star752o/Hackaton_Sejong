package jp;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import ssaemo.*;

public class IdeaNotes extends JPanel {
	int xpos = 0;
	int ypos = 0;
	int noteW = 200;
	int noteH = 150;
	int clickedXpos = 0;
	int clickedYpos = 0;
	int endXpos = 0;
	int endYpos = 0;
	
	public IdeaNotes(){
		
		this.setSize(1003, 650);
		setLayout(null);
		JPanel drawPanel = new JPanel();
		drawPanel.setBackground(Color.ORANGE);
		drawPanel.setBounds(0, 0, 1003, 650);
		drawPanel.setLayout(null);
		this.add(drawPanel);
		
		Connection conn = DBConnector.getInstance().getConnection();
		ResultSet rs = NoteTBController.getInstance().getNotes(conn);
		
		try
		{
			while(rs.next())
			{
				int xpos = rs.getInt("xpos");
				int ypos = rs.getInt("ypos");
				//System.out.println("xpos: " + xpos);
				//System.out.println("ypos: " + ypos);
				String str = rs.getString("contents");
				
				Notes note = new Notes(xpos, ypos, str, noteW, noteH);
				note.btnCommit.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						NoteTBController.getInstance().updateNote(conn, note);
					}
				});
				note.delete.addMouseListener(new MouseAdapter(){
					//@Override
					public void mouseClicked(MouseEvent e){
						note.setVisible(false);
						///DELETE to DB
					}
				});
				
				note.text.addMouseListener(new MouseAdapter(){
					public void mousePressed(MouseEvent e){
						clickedXpos = e.getX();
						clickedYpos = e.getY();
					}
				});
				
				note.text.addMouseListener(new MouseAdapter(){
					public void mouseReleased(MouseEvent e){
						endXpos = e.getX();
						endYpos = e.getY();
						
						note.xpos = note.xpos + endXpos - clickedXpos;
						note.ypos = note.ypos + endYpos - clickedYpos;
						note.setBounds(note.xpos, note.ypos, noteW, noteH);
						///UPDATE to DB
						
						repaint();
					}
				});
				drawPanel.add(note);
			}
		}
		catch(SQLException e) { e.printStackTrace(); }
		
		JLabel lbl = new JLabel("Start new Stickey Note, Click anywhere of the orange screen.");
		JLabel lbl2 = new JLabel("Delete exists Stickey Note, Click the red square.");
		JLabel lbl3 = new JLabel("Move Stickey Note, Drag note where you want to put.");
		
		lbl.setBounds(5, 5, 1003, 15);
		lbl2.setBounds(5, 25, 1003, 15);
		lbl3.setBounds(5, 45, 1003, 15);
		
		drawPanel.add(lbl);
		drawPanel.add(lbl2);
		drawPanel.add(lbl3);
		
		drawPanel.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				clickedXpos = e.getX();
				clickedYpos = e.getY();
				
				Notes note = new Notes();
				note.xpos = clickedXpos;
				note.ypos = clickedYpos;
				note.setBounds(clickedXpos, clickedYpos, noteW, noteH);
				note.btnCommit.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						NoteTBController.getInstance().updateNote(conn, note);
					}
				});
				note.delete.addMouseListener(new MouseAdapter(){
					@Override
					public void mouseClicked(MouseEvent e){
						note.setVisible(false);
						///DELETE to DB
					}
				});
				
				note.text.addMouseListener(new MouseAdapter(){
					public void mousePressed(MouseEvent e){
						clickedXpos = e.getX();
						clickedYpos = e.getY();
					}
				});
				
				note.text.addMouseListener(new MouseAdapter(){
					public void mouseReleased(MouseEvent e){
						endXpos = e.getX();
						endYpos = e.getY();
						
						note.xpos = note.xpos + endXpos - clickedXpos;
						note.ypos = note.ypos + endYpos - clickedYpos;
						note.setBounds(note.xpos, note.ypos, noteW, noteH);
						///UPDATE to DB
						
						repaint();
					}
				});
				
				drawPanel.add(note);
				repaint();
				
				Connection conn = DBConnector.getInstance().getConnection();
				NoteTBController.getInstance().insertNote(conn, note);
			}
		});		
	}
}
