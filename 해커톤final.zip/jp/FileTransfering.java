package jp;

import java.sql.*;
import java.io.*;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import ssaemo.DBConnector;
import ssaemo.FileController;

public class FileTransfering extends JPanel {
	String filename = "";
	public FileTransfering(){
		this.setSize(1003, 650);
		this.setLayout(null);
		
		/*File load Table*/
		JScrollPane scrollPane = new JScrollPane();
		JPanel filePnl = new JPanel();
		scrollPane.setViewportView(filePnl);
		scrollPane.setBounds(25, 60, 1003-50, 600-60-10);
		add(scrollPane);
		filePnl.setSize(1003-50, 1200);
		filePnl.setBackground(Color.CYAN);
		//scrollPane.add(filePnl);
		
		/*Main control buttons*/
		JButton loadList = new JButton("Load List");
		loadList.setBounds(25, 25, 120, 25);
		this.add(loadList);
		loadList.addMouseListener(new MouseAdapter(){
			//@Override
			public void mouseClicked(MouseEvent e){
				//GET DB
				ResultSet rs = null;
				int posX = 5;
				int posY = 5;
				int box1W = 650;
				int box1H = 25;
				int gap = 5;
				int btnW = 150;
				int btnH = 25;
				filePnl.removeAll();
				try{
					while(rs.next()){
						File file = new File();
						file.file_name = rs.getString("file_name");
						file.owner_id = rs.getInt("id");
						
						file.file_box = new JTextArea(file.file_name);
						file.file_box.setBounds(posX, posY, box1W, box1H);
						file.file_box.setEditable(false);
						filePnl.add(file.file_box);
						
						file.download = new JButton("Download");
						file.download.setBounds(posX+box1W+gap, posY, btnW, btnH);
						file.download.addMouseListener(new MouseAdapter(){
							public void mouseClicked(MouseEvent e){
								///start file download
							}
						});
						filePnl.add(file.download);
						
						posY = posY + box1H + gap;
					}
				}
				catch(Exception err){}
			}
		});
		
		JTextArea inputFileName = new JTextArea();
		inputFileName.setBounds(150-40, 600, 600+20, 25);
		this.add(inputFileName);
		
		JLabel bottomLbl = new JLabel("File Upload : ");
		bottomLbl.setBounds(25, 600, 80, 25);
		this.add(bottomLbl);
		
		JButton findFile = new JButton("Browse..");
		findFile.setBounds(755, 600, 100, 25);
		this.add(findFile);
		findFile.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				//start pop-up to select file
			}
		});
		
		JButton uploadFile = new JButton("Upload");
		uploadFile.setBounds(860, 600, 100, 25);
		this.add(uploadFile);
		uploadFile.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				//start upload file given file
				FileInputStream in = null;
				//start upload file given file
				try{
					in = new FileInputStream(filename);
					byte arr[] = new byte[16000000];
					int num = in.read(arr);
					Connection conn = DBConnector.getInstance().getConnection();
					
					FileController.getInstance().uploadFile(conn,filename,arr);
				}
				catch(FileNotFoundException fnfe)
				{
					System.out.println(filename + "������ �������� �ʽ��ϴ�.");
				}
				catch(IOException ioe)
				{
					System.out.println(filename + "������ ���� �� �����ϴ�.");
				}
				
				finally
				{
					try
					{
						in.close();
					}
					catch(Exception ee)
					{
						System.out.println("���� �ݱ� ����");
					}
				}
			}
		});
		
		
	}

}
