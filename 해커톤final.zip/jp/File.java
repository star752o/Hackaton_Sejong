package jp;

import javax.swing.JButton;
import javax.swing.JTextArea;

public class File {
	public String file_name;
	public int owner_id;
	public JTextArea file_box;
	public JButton download;
}